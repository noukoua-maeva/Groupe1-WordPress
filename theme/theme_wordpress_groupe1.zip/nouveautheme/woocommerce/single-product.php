<?php
get_header();
?>
<div class="single-product-page">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <div class="product-detail">
            <div class="product-image">
                <?php the_post_thumbnail('large'); ?>
            </div>
            <div class="product-info">
                <h1><?php the_title(); ?></h1>
                <p class="price"><?php echo wc_price(get_post_meta(get_the_ID(), '_price', true)); ?></p>
                <div class="description">
                    <?php the_content(); ?>
                </div>
                <button class="add-to-cart-button">
                    Ajouter au panier
                </button>
            </div>
        </div>
    <?php endwhile; endif; ?>
</div>
<?php
get_footer();
?>
