<div class="product-item">
    <a href="<?php the_permalink(); ?>">
        <?php the_post_thumbnail('medium'); ?>
        <h3><?php the_title(); ?></h3>
        <p><?php echo wc_price(get_post_meta(get_the_ID(), '_price', true)); ?></p>
    </a>
</div>
