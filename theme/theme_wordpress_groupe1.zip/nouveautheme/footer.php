<footer class="footer">
    <div class="container">
        <div class="footer-widgets">
            <?php dynamic_sidebar('footer-widgets'); ?>
        </div>
        <ul class="social-links">
            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
        </ul>
        <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Tous droits réservés.</p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
