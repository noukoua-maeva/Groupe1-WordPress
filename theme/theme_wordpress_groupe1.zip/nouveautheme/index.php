<?php get_header(); ?>
<div class="container">
    <section class="hero">
        <h1>Bienvenue chez <?php bloginfo('name'); ?></h1>
        <p>Découvrez nos produits phares.</p>
        <a class="cta-button" href="<?php echo esc_url(home_url('/boutique')); ?>">Voir les produits</a>
    </section>
</div>
<div class="products-container">
    <?php 
    // Boucle WordPress pour afficher les produits
    if (have_posts()) : 
        while (have_posts()) : the_post();
            if ('product' === get_post_type()) :
    ?>
            <div class="product">
                <a href="<?php the_permalink(); ?>">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>" />
                    <?php endif; ?>
                    <h3><?php the_title(); ?></h3>
                    <p><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                    <span class="price"><?php echo wc_price(get_post_meta(get_the_ID(), '_price', true)); ?></span>
                </a>
            </div>
    <?php 
            endif;
        endwhile;
    endif;
    ?>
</div>

<?php get_footer(); ?>
