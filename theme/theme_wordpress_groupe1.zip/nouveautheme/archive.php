<section class="products-page">
    <div class="container">
        <h1>Nos Produits</h1>
        <p id="product-counter">Chargement...</p>
        <div class="products-list">
            <?php
            $count = wp_count_posts('product')->publish;
            echo "<script>document.getElementById('product-counter').innerText = 'Total produits : $count';</script>";
            if (have_posts()) :
                while (have_posts()) : the_post(); ?>
                    <div class="product-item">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('medium'); ?>
                            <h2><?php the_title(); ?></h2>
                            <span class="price"><?php echo get_post_meta(get_the_ID(), '_price', true); ?>FCFA</span>
                        </a>
                    </div>
                <?php endwhile;
            endif;
            ?>
        </div>
    </div>
</section>
