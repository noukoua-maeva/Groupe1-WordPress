<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title><?php wp_title(); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header>
    <div class="container">
       
        <nav class="navbar">
        
            <ul class="nav-links">
                <li><a href="<?php echo home_url(); ?>" class="logo"><?php bloginfo('name'); ?></a></li>
                <li><a href="<?php echo home_url(); ?>"><i class="fas fa-home"></i> Accueil</a></li>
                <li><a href="<?php echo site_url('/produits'); ?>"><i class="fas fa-cogs"></i> Produits</a></li>
                <li><a href="<?php echo site_url('/a-propos'); ?>"><i class="fas fa-info-circle"></i> À propos</a></li>
                <li><a href="<?php echo site_url('/contact'); ?>"><i class="fas fa-envelope"></i> Contact</a></li>
            </ul>
            <div class="cta">
                <a href="<?php echo site_url('/special-offers'); ?>"><i class="fas fa-tag"></i> Offres spéciales</a>
            </div>
            <div class="dark-mode-toggle" id="dark-mode-toggle">
                <i class="fas fa-sun"></i>
            </div>
        </nav>
    </div>
</header>
