<?php
function quifeurou_setup() {
    // Ajouter le support pour les menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'quifeurou'),
    ));

    // Ajouter le support pour les miniatures
    add_theme_support('post-thumbnails');

    // Ajouter le support pour les widgets
    add_theme_support('widgets');
}
add_action('after_setup_theme', 'quifeurou_setup');

function quifeurou_widgets_init() {
    register_sidebar(array(
        'name' => __('Sidebar', 'quifeurou'),
        'id' => 'sidebar-1',
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => __('Footer Widgets', 'quifeurou'),
        'id' => 'footer-widgets',
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
}
add_action('widgets_init', 'quifeurou_widgets_init');

function quifeurou_scripts() {
    wp_enqueue_style('quifeurou-style', get_stylesheet_uri());
    wp_enqueue_style('roboto', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');
    wp_enqueue_script('quifeurou-script', get_template_directory_uri() . '/js/script.js', array(), '1.0', true);
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
}
add_action('wp_enqueue_scripts', 'quifeurou_scripts');

// Ajouter des options de personnalisation
function quifeurou_customize_register($wp_customize) {
    $wp_customize->add_section('quifeurou_colors', array(
        'title' => __('Colors', 'quifeurou'),
        'priority' => 30,
    ));

    $wp_customize->add_setting('quifeurou_primary_color', array(
        'default' => '#007bff',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'quifeurou_primary_color_control', array(
        'label' => __('Primary Color', 'quifeurou'),
        'section' => 'quifeurou_colors',
        'settings' => 'quifeurou_primary_color',
    )));
}
add_action('customize_register', 'quifeurou_customize_register');

function quifeurou_customize_css() {
    ?>
    <style>
        a, .main-navigation a, .featured-section .button {
            color: <?php echo get_theme_mod('quifeurou_primary_color', '#007bff'); ?>;
        }
        .featured-section .button:hover {
            background-color: <?php echo get_theme_mod('quifeurou_primary_color', '#007bff'); ?>;
        }
    </style>
    <?php
}
add_action('wp_head', 'quifeurou_customize_css');
